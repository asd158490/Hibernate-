package util;

public class FrontUtil {

}
