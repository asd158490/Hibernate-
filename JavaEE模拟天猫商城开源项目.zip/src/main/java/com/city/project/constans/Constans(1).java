
package com.city.project.constans;

public class Constans {

    public static final String fromMail = "1183952393@qq.com";

    public static final String fromMailPassword = "wqgdrdpzvkgiidgi";

    public static final String fromMailAuthorization = "wqgdrdpzvkgiidgi";

    public static final String toMail = "1183952393@qq.com";

}
