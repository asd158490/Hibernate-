package com.city.project.service;

import java.util.List;

import com.city.servlet.model.CartItem;

public interface ICartItemService {
	int getTotal(int uid);
	void update(CartItem bean);
	 void add(CartItem bean);
	 void delete(int id);
	 CartItem get(int id);
	 List<CartItem> listByUser(int uid, int start , int count);
	 List<CartItem> listByUser(int uid);
}
