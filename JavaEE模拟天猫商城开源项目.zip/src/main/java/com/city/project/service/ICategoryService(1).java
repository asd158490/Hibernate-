package com.city.project.service;

import java.util.List;

import com.city.servlet.model.Category;

public interface ICategoryService {
	int getTotal();
	void add(Category bean);
	void update(Category bean);
	void delete(int id);
	 Category get(int id);
	 List<Category> list(int start , int count);
	 List<Category> list();
	 List<Category> listInHome();
}
