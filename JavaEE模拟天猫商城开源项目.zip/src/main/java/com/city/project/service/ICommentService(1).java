package com.city.project.service;

import java.util.List;

import com.city.servlet.model.Comment;

public interface ICommentService {

	int getTotalByProduct(int pid);
	void add(Comment bean);
	 void update(Comment bean);
	 void delete(int id);
	 Comment get(int id);
	 Comment get(int pid,int uid);
	 List<Comment> list(int pid, int start , int count);
	 List<Comment> list(int pid);}
	 
