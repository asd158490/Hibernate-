package com.city.project.service;

import java.util.List;

import com.city.servlet.model.Product;

public interface IProductService {
	int getTotal(int cid);
	void add(Product bean);
	void update(Product bean);
	 void delete(int id);
	 Product get(int id);

	 List<Product> listByCategory(int cid, int start , int count);
	 List<Product> listByCategory(int cid);
	 List<Product> listBySearch(String keyword, int start , int count);
	 List<Product> listBySearch(String keyword);
}
