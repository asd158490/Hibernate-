package com.city.project.service;

import com.city.servlet.model.PropertyValue;

public interface IPropertyValueService {
	void add(PropertyValue bean);
	void update(PropertyValue bean);
	 void delete(int id);
	 PropertyValue get(int id);
	 PropertyValue get(int ptid,int pid);

}
