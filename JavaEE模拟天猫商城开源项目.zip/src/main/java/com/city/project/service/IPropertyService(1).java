package com.city.project.service;

import java.util.HashMap;
import java.util.List;

import com.city.servlet.model.Product;
import com.city.servlet.model.Property;
import com.city.servlet.model.PropertyValue;

public interface IPropertyService {
	int getTotal(int cid);
	 void add(Property bean);
	 void update(Property bean);
	 void delete(int id);
	 Property get(int id);
	 List<Property> list(int cid,int start ,int count);
	 List<Property> list(int cid);
	 HashMap<Property,PropertyValue> list(Product p);
}
