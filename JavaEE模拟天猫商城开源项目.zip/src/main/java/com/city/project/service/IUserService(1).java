package com.city.project.service;

import java.util.List;

import com.city.servlet.model.User;

public interface IUserService {
	int getTotal();
	void add(User bean);
	void update(User bean);
	void delete(int id);
	User get(int id);
	User get(String name);
	User get(String name,String password);
	boolean passwordIsRight(String id,String password);
	boolean isExist(String name);
	List<User> list(int start , int count);
	List<User> list();
}
