package com.city.project.service;
import java.util.List;

import com.city.servlet.model.ProductImage;

public interface IProductImageService {
	void add(ProductImage bean);
	 void update(ProductImage bean);
	 void delete(int id);
	 ProductImage get(int id);
	 ProductImage getFirstImage(int pid);
	 List<ProductImage> listTopImage(int pid, int start , int count);List<ProductImage> listDetailImage(int pid, int start , int count);
}
