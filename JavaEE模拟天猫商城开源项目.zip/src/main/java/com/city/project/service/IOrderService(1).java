package com.city.project.service;

import java.util.List;

import com.city.servlet.model.Order;

public interface IOrderService {

	int getTotal();
	void add(Order bean);
	void update(Order bean);
	void delete(int id);
	
	 Order get(int id);
	 List<Order> list(int uid, int start , int count);

	    public List<Order> list(int start , int count);
	    List<Order> list(int uid);
	    List<Order> list();
}
