package com.city.project.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.util.Properties;

/**
 * Application Lifecycle Listener implementation class ServerStartAndStopListener
 *
 */
@WebListener
public class ServerStartAndStopListener implements ServletContextListener {

    /**
     * Default constructor.
     */
    public ServerStartAndStopListener() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0) {
        System.out.print("服务器已经停止了");
    }

    /**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg0) {
        // TODO Auto-generated method stub
        System.out.println("请登录你的账户");
        ServletContext application = arg0.getServletContext();
        application.setAttribute("onlinenum", 0);
        application.setAttribute("clicknum", 0);
        application.setAttribute("buyknum", 0);
    }

}
