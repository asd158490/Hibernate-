package com.city.project.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
@WebListener
public class UserBuyNumAddListener implements ServletRequestListener {

	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		// TODO Auto-generated method stub
		
	}
	@Override
	 public void requestInitialized(ServletRequestEvent arg0)  { 
         // TODO Auto-generated method stub
    	ServletContext application=arg0.getServletContext();
        int n=(Integer)application.getAttribute("buyknum")+1;
        application.setAttribute("buyknum", n);
    }

}
