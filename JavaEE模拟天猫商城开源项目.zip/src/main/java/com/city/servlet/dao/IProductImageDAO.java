package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.Product;
import com.city.servlet.model.ProductImage;

public interface IProductImageDAO {
	int getTotal();
	void add(ProductImage bean);
	 void update(ProductImage bean);
	 void delete(int id);
	 List<ProductImage> list(int pid ,String type, int start , int count);
	 ProductImage get(int id);
	
}
