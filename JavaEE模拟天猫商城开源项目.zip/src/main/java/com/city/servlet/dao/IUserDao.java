package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.User;

public interface IUserDao {
	int getTotal();
	void add(User bean);
	void update(User bean);
	void delete(int id);
	List<User> list(int start , int count);
	User get(int id);
	 User get(String name);
	 User get(String name, String password);
	 
}
