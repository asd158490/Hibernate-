package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.Category;

public interface ICategoryDAO {
	int getTotal();
	void add(Category bean);
	void update(Category bean);
	void delete(int id);
	Category get(int id);
	 List<Category> list(int start ,int count);
	 
}
