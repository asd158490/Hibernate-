package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.Property;

public interface IPropertyDAO {
	int getTotal(int cid);
	void add(Property bean);
	void update(Property bean);
	void delete(int id);
	Property get(int id);
	List<Property> list(int cid,int start ,int count) ;
}
