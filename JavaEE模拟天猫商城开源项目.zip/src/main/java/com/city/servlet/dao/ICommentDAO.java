package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.Comment;

public interface ICommentDAO {
	int getTotal();
	 int getTotalByProduct(int pid);
	 void add(Comment bean);
	 void update(Comment bean);
	 void delete(int id);
	 Comment get(int id);
	 Comment get(int pid,int uid);
	 List<Comment> list(int pid,int start , int count);
}
