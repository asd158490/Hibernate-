package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.CartItem;

public interface ICartItemDAO {
	int getTotal(int uid);
	void add(CartItem bean);
	void update(CartItem bean);
	void delete(int id);
	CartItem get(int id);
	 List<CartItem> listByUser(int uid, int start , int count);
	 List<CartItem> listByUser(int uid);
}
