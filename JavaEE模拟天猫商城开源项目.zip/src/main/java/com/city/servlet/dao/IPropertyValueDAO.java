package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.PropertyValue;

public interface IPropertyValueDAO  {
	 int getTotal();
	 void add(PropertyValue bean);
	 void update(PropertyValue bean);
	 void delete(int id);
	 PropertyValue get(int id);
	 PropertyValue get(int ptid,int pid);
	 List<PropertyValue> list(int pid);
	 List<PropertyValue> list(int start , int count);
}
