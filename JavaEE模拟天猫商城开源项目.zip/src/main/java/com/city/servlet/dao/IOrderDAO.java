package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.Order;

public interface IOrderDAO {
	int getTotal();
	 void add(Order bean);
	 void update(Order bean);
	 void delete(int id);
	 Order get(int id);
	 List<Order> list(int start , int count);
	 List<Order> list();
	 List<Order> list(int uid,int start , int count);

}
