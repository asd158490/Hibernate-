package com.city.servlet.dao;

import java.util.List;

import com.city.servlet.model.OrderItem;

public interface IOrderItemDAO {
	int getTotal();
	 int getTotalByProduct(int pid);
	 void add(OrderItem bean);
	 void update(OrderItem bean);
	 void delete(int id);
	 OrderItem get(int id);
	 List<OrderItem> listByOrder(int oid, int start , int count);
	 List<OrderItem> listByProduct(int pid, int start , int count);

}
