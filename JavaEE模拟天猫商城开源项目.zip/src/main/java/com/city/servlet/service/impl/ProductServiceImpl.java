package com.city.servlet.service.impl;

import java.util.List;

import com.city.project.service.IProductService;
import com.city.servlet.dao.impl.ProductDAOImpl;
import com.city.servlet.model.Product;

public class ProductServiceImpl implements IProductService{

    private ProductDAOImpl dao = new ProductDAOImpl();
    public int getTotal(int cid){return dao.getTotal(cid);}
    public void add(Product bean) {
        dao.add(bean);
    }
    public void update(Product bean) {
        dao.update(bean);
    }
    public void delete(int id) {
        dao.delete(id);
    }
    public Product get(int id){
        Product product = dao.get(id);
        fill(product);
        return product;
    }
    private void fill(Product rawProduct){
        rawProduct.setFirstProductImage(new ProductImageServiceImpl().getFirstImage(rawProduct.getId()));
        rawProduct.setSaleCount(new OrderItemServiceImpl().getTotalByProduct(rawProduct.getId()));
        rawProduct.setCommentCount(new CommentServiceImpl().getTotalByProduct(rawProduct.getId()));
    }
    private void fill(List<Product> rawProductList){
        for(Product rawProduct : rawProductList){
            fill(rawProduct);
        }
    }
    public List<Product> listByCategory(int cid, int start , int count){
        List<Product> products =  dao.listByCategory(cid,start,count);
        fill(products);
        return products;
    }
    public List<Product> listByCategory(int cid){
        return this.listByCategory(cid,0,Short.MAX_VALUE);
    }
    public List<Product> listBySearch(String keyword, int start , int count){
        List<Product> products = dao.listBySearch(keyword,start , count);
        fill(products);
        return products;
    }
    public List<Product> listBySearch(String keyword){
        return this.listBySearch(keyword,0,Short.MAX_VALUE);
    }

}
