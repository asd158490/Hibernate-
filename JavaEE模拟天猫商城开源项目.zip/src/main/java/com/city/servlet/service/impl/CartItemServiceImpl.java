package com.city.servlet.service.impl;

import java.util.List;

import com.city.project.service.ICartItemService;
import com.city.servlet.dao.impl.CartItemDAOImpl;
import com.city.servlet.model.CartItem;

public class CartItemServiceImpl implements ICartItemService {
    private CartItemDAOImpl dao = new CartItemDAOImpl();
    public int getTotal(int uid){return dao.getTotal(uid);}
    public void add(CartItem bean) {
        dao.add(bean);
    }
    public void update(CartItem bean) {
        dao.update(bean);
    }
    public void delete(int id) {
        dao.delete(id);
    }
    public CartItem get(int id){
        return dao.get(id);
    }
    public List<CartItem> listByUser(int uid, int start , int count){
        return dao.listByUser(uid,start,count);
    }
    public List<CartItem> listByUser(int uid){
        return dao.listByUser(uid,0,Short.MAX_VALUE);
    }
}
