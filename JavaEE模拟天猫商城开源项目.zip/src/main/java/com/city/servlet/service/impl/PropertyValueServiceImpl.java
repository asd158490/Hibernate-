package com.city.servlet.service.impl;

import java.util.HashMap;
import java.util.List;

import com.city.project.service.IPropertyValueService;
import com.city.servlet.dao.impl.PropertyValueDaoImpl;
import com.city.servlet.model.Product;
import com.city.servlet.model.Property;
import com.city.servlet.model.PropertyValue;

public class PropertyValueServiceImpl implements  IPropertyValueService {
    private PropertyValueDaoImpl dao = new PropertyValueDaoImpl();
    public void add(PropertyValue bean) {
        dao.add(bean);
    }
    public void update(PropertyValue bean) {
        dao.update(bean);
    }
    public void delete(int id) {
        dao.delete(id);
    }
    public PropertyValue get(int id){
        return dao.get(id);
    }
    public PropertyValue get(int ptid,int pid){
        return dao.get(ptid,pid);
    }
}
