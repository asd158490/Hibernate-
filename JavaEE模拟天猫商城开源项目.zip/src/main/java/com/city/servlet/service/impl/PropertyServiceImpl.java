package com.city.servlet.service.impl;

import java.util.HashMap;
import java.util.List;

import com.city.project.service.IPropertyService;
import com.city.servlet.dao.impl.PropertyDaoImpl;
import com.city.servlet.dao.impl.PropertyValueDaoImpl;
import com.city.servlet.model.Product;
import com.city.servlet.model.Property;
import com.city.servlet.model.PropertyValue;

public class PropertyServiceImpl  implements IPropertyService{
    private PropertyDaoImpl dao = new PropertyDaoImpl();
    public int getTotal(int cid) {return dao.getTotal(cid);}
    public void add(Property bean) {
        dao.add(bean);
    }
    public void update(Property bean) {
        dao.update(bean);
    }
    public void delete(int id) {
        dao.delete(id);
    }
    public Property get(int id){
        return dao.get(id);
    }
    public List<Property> list(int cid,int start ,int count){
        return dao.list(cid,start,count);
    }
    public List<Property> list(int cid){return dao.list(cid,0,Short.MAX_VALUE);}
    public HashMap<Property,PropertyValue> list(Product p){
        HashMap<Property,PropertyValue> result = new HashMap<>();
        List<Property> PropertiesInCategory = this.list(p.getCategory().getId());
        for (Property pt: PropertiesInCategory) {
            PropertyValue value = new PropertyValueDaoImpl().get(pt.getId(),p.getId());
            if(null==value){
                value = new PropertyValue();
                value.setProduct(p);
                value.setProperty(pt);
            }
            result.put(pt,value);
        }
        return result;
    }
}
