package com.city.servlet.service.impl;

import java.math.BigDecimal;
import java.util.List;
import com.city.project.service.IOrderService;
import com.city.servlet.dao.impl.OrderDAOImpl;
import com.city.servlet.model.Order;
import com.city.servlet.model.OrderItem;

public class OrderServiceImpl implements IOrderService {
    public static class OrderType {
        public static final String WAIT_PAY = "waitPay";
        public static final String WAIT_DELIVERY = "waitDelivery";
        public static final String WAIT_CONFIRM = "waitConfirm";
        public static final String WAIT_REVIEW = "waitReview";
        public static final String FINISH = "finish";
    }
    private OrderDAOImpl dao = new OrderDAOImpl();
    public int getTotal() {return dao.getTotal();}
    public void add(Order bean) {
        dao.add(bean);
    }
    public void update(Order bean) {
        dao.update(bean);
    }
    public void delete(int id) {
        dao.delete(id);
    }

    private void fill(Order rawOrder){
        List<OrderItem> ois = new OrderItemServiceImpl().listByOrder(rawOrder.getId());
        BigDecimal totalPrice = new BigDecimal(0);
        int totalNumber = 0;
        for(OrderItem oi:ois){
            totalNumber += oi.getNumber();
            BigDecimal thisPrice =  new BigDecimal(oi.getNumber()).multiply(oi.getProduct().getNowPrice());
            totalPrice = totalPrice.add(thisPrice);
        }
        rawOrder.setOrderItems(ois);
        rawOrder.setTotalNumber(totalNumber);
        rawOrder.setTotalPrice(totalPrice);

    }

    public Order get(int id){
        Order o =  dao.get(id);
        fill(o);
        return o;
    }

    public List<Order> list(int uid, int start , int count){
        List<Order> orderList =  dao.list(uid,start,count);
        for(Order o : orderList){
            fill(o);
        }
        return orderList;
    }

    public List<Order> list(int start , int count){
        List<Order> orderList =  dao.list(start,count);
        for(Order o : orderList){
            fill(o);
        }
        return orderList;
    }
    public List<Order> list(int uid){
        return this.list(uid,0,Short.MAX_VALUE);
    }
    public List<Order> list(){
        return dao.list(0,Short.MAX_VALUE);
    }
}
