package com.city.servlet.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.city.servlet.model.User;
import com.city.servlet.service.impl.UserServiceImpl;
import com.city.servlet.util.Pagination;
import com.city.servlet.util.PaginationUtil;

import java.util.List;

public class UserController extends BaseController {
    private UserServiceImpl service = new UserServiceImpl();
    public String list(HttpServletRequest request, HttpServletResponse response){
        Pagination pagination= PaginationUtil.createPagination(request,service.getTotal());
        List<User> users = service.list(pagination.getStart(),pagination.getCount());
        request.setAttribute("users",users);
        request.setAttribute("pagination",pagination);
        return "jsp/admin/listUser.jsp";
    }
}
