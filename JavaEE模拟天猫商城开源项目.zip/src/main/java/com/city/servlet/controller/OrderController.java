package com.city.servlet.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.city.servlet.model.Order;
import com.city.servlet.service.impl.OrderServiceImpl;
import com.city.servlet.util.Pagination;
import com.city.servlet.util.PaginationUtil;

import java.util.Date;
import java.util.List;

public class OrderController extends BaseController {
    private OrderServiceImpl service = new OrderServiceImpl();
    public String list(HttpServletRequest request, HttpServletResponse response){
        Pagination pagination= PaginationUtil.createPagination(request,service.getTotal());
        List<Order> orders = service.list(pagination.getStart(),pagination.getCount());
        request.setAttribute("orders",orders);
        request.setAttribute("pagination",pagination);
        return "jsp/admin/listOrder.jsp";
    }
    public String delivery(HttpServletRequest request, HttpServletResponse response){
        int oid = Integer.parseInt(request.getParameter("oid"));
        Order order = service.get(oid);
        order.setStatus(OrderServiceImpl.OrderType.WAIT_CONFIRM);
        order.setDeliverDate(new Date());
        service.update(order);
        return "@/admin/order_list";
    }
}
