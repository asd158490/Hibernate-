package com.city.servlet.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.city.servlet.service.impl.PropertyServiceImpl;

/**
 * Servlet implementation class PropertyDeleteController
 */
public class PropertyDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PropertyServiceImpl service = new PropertyServiceImpl();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PropertyDeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int cid = Integer.parseInt(request.getParameter("cid"));
		int ptid = Integer.parseInt(request.getParameter("ptid"));
		service.delete(ptid);
		return "@/admin/property_list?cid="+cid;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
