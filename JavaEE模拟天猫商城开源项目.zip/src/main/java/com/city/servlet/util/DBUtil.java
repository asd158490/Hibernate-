package com.city.servlet.util;

import java.sql.Connection;

import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {
   
  
    public static Connection getConnection() throws SQLException{
    	Connection cn=null;
		try {
			Context ctx = new InitialContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/cityoa");
			cn=ds.getConnection();
			ctx.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("连接数据库失败");
		}
		return cn;
		
	}

    }
