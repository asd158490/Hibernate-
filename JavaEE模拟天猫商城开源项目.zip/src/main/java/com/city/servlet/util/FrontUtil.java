package com.city.servlet.util;

public class FrontUtil {

}
