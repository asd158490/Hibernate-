package com.city.servlet.util;

import com.city.project.constans.Constans;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class MailUtil {

    public static void sendMessage(String str) {
        //         发送邮件
//         做链接前的准备工作 也就是参数初始化
        Properties properties = new Properties();
        properties.setProperty("mail.smtp.host", "smtp.qq.com");// 发送邮箱服务器
        properties.setProperty("mail.smtp.port", "465");// 发送端口
        properties.setProperty("mail.smtp.auth", "true");// 是否开启权限控制
        properties.setProperty("mail.debug", "true");// true 打印信息到控制台
        properties.setProperty("mail.transport", "smtp");// 发送的协议是简单的邮件传输协议
        properties.setProperty("mail.smtp.ssl.enable", "true");
        // 建立两点之间的链接
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(Constans.fromMail, Constans.fromMailAuthorization);
            }
        });
        // 创建邮件对象
        Message message = new MimeMessage(session);
        // 设置发件人
        try {
            message.setFrom(new InternetAddress(Constans.fromMail));

            // 设置收件人
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(Constans.toMail));// 收件人
            // 设置主题
            message.setSubject("提示");
            // 设置邮件正文 第二个参数是邮件发送的类型
            message.setContent(str, "text/html;charset=UTF-8");
            // 发送一封邮件
            Transport transport = session.getTransport();
            transport.connect(Constans.fromMail, Constans.fromMailPassword);
            Transport.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        } finally {

        }
    }
}
