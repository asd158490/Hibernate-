package com.city.servlet.factory;

import com.city.project.service.IUserService;
import com.city.servlet.service.impl.UserServiceImpl;

public class ServiceFactory {
     public static IUserService getUserService() {
        return new UserServiceImpl();
     }


}
