package com.city.servlet.factory;

import com.city.servlet.dao.IUserDao;
import com.city.servlet.dao.impl.UserDaoImpl;

public class DaoFactory {
    public static IUserDao getUserDao() {
        return new UserDaoImpl();
    }
    
    

    
}
